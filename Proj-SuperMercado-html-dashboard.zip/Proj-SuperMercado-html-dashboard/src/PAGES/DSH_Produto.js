import React, { useState } from 'react';
import { Modal, Button } from 'react-bootstrap';
import Sidebar from './component/Sidebar'; // Ajuste o caminho se necessário

export const DSH_Produto = () => {
    const [showEditModal, setShowEditModal] = useState(false);
    const [showRemoveModal, setShowRemoveModal] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState(null);

    const products = [
        {
            id: 1,
            nome: 'Arroz',
            categoria: 'Alimentos',
            preco: 25.99,
            unidade: 'kg',
            descricao: 'Arroz branco tipo 1, pacote de 5 kg.'
        },
        {
            id: 2,
            nome: 'Leite',
            categoria: 'Bebidas',
            preco: 4.50,
            unidade: 'litro',
            descricao: 'Leite integral, caixa de 1 litro.'
        },
        {
            id: 3,
            nome: 'Sabão em Pó',
            categoria: 'Limpeza',
            preco: 12.99,
            unidade: 'kg',
            descricao: 'Sabão em pó para roupas, pacote de 1 kg.'
        },
        {
            id: 4,
            nome: 'Chips',
            categoria: 'Alimentos',
            preco: 8.99,
            unidade: 'g',
            descricao: 'Salgadinho Elma Chips, pacote de 500 g.'
        },
        {
            id: 5,
            nome: 'Vassoura',
            categoria: 'Limpeza',
            preco: 8.99,
            unidade: 'kg',
            descricao: 'Vassoura do Harry Potter, peso de 0,300 kg.'
        },
        {
            id: 6,
            nome: 'Cream Cracker',
            categoria: 'Alimentos',
            preco: 3.99,
            unidade: 'g',
            descricao: 'Bolacha Cream Cracker, pacote de 30 g.'
        },
        {
            id: 7,
            nome: 'Esponja',
            categoria: 'Limpeza',
            preco: 2.99,
            unidade: 'g',
            descricao: 'Esponja de cozinha Scoth Brite, pacote de 10 g.'
        },
        {
            id: 8,
            nome: 'Monster',
            categoria: 'Bebidas',
            preco: 9.99,
            unidade: 'ml',
            descricao: 'Monster Energy, lata de 473 ml.'
        }
    ];
    //MOSTRAR MODAL DE EDIÇÃO
    const handleEdit = (product) => {
        setSelectedProduct(product);
        setShowEditModal(true);
    };
     //MOSTRAR MODAL DE REMOÇÃO
    const handleRemove = (product) => {
        setSelectedProduct(product);
        setShowRemoveModal(true);
    };
    //FECHAR OS MODAIS
    const handleCloseEditModal = () => {
        setShowEditModal(false);
        setSelectedProduct(null);
    };

    const handleCloseRemoveModal = () => {
        setShowRemoveModal(false);
        setSelectedProduct(null);
    };
    //-**--**--
    const handleSaveEdit = () => {
        // LOGICA DE EDITAR
        handleCloseEditModal();
    };

    const handleConfirmRemove = () => {
        // LOGICA DE REMOVER
        handleCloseRemoveModal();
    };

    return (
        <div className="container-fluid">
            <div className="row flex-nowrap">
                <div className="col-md-2">
                    <Sidebar />
                </div>
                <div className="col py-3">
                    <h1>PRODUTO</h1>
                    <ul className="list-group">
                        {products.map((product) => (
                            <li key={product.id} className="list-group-item d-flex justify-content-between align-items-center">
                                ID:{product.id} | {product.nome} | Categoria: {product.categoria} | Preço: R${product.preco}
                                <div>
                                    <button
                                        className="btn btn-warning btn-sm me-2"
                                        onClick={() => handleEdit(product)}
                                    >
                                        Editar
                                    </button>
                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => handleRemove(product)}
                                    >
                                        Remover
                                    </button>
                                </div>
                            </li>
                        ))}
                    </ul>

                    {/* Edit Modal */}
                    <Modal show={showEditModal} onHide={handleCloseEditModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Editar Produto</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <form>
                                <div className="mb-3">
                                    <label htmlFor="productName" className="form-label">Nome</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="productName"
                                        defaultValue={selectedProduct?.nome || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="productCategory" className="form-label">Categoria</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="productCategory"
                                        defaultValue={selectedProduct?.categoria || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="productPrice" className="form-label">Preço</label>
                                    <input
                                        type="number"
                                        step="0.01"
                                        className="form-control"
                                        id="productPrice"
                                        defaultValue={selectedProduct?.preco || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="productUnit" className="form-label">Unidade</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="productUnit"
                                        defaultValue={selectedProduct?.unidade || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="productDescription" className="form-label">Descrição</label>
                                    <textarea
                                        className="form-control"
                                        id="productDescription"
                                        rows="3"
                                        defaultValue={selectedProduct?.descricao || ''}
                                    ></textarea>
                                </div>
                            </form>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseEditModal}>
                                Fechar
                            </Button>
                            <Button variant="primary" onClick={handleSaveEdit}>
                                Salvar
                            </Button>
                        </Modal.Footer>
                    </Modal>

                    {/* Remove Modal */}
                    <Modal show={showRemoveModal} onHide={handleCloseRemoveModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Confirmar Remoção</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            Tem certeza de que deseja remover o produto "{selectedProduct?.nome}"?
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseRemoveModal}>
                                Cancelar
                            </Button>
                            <Button variant="danger" onClick={handleConfirmRemove}>
                                Remover
                            </Button>
                        </Modal.Footer>
                    </Modal>
                </div>
            </div>
        </div>
    );
};
