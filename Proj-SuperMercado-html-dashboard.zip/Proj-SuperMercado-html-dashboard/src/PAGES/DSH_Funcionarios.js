import React, { useState } from 'react';
import Sidebar from './component/Sidebar';
import { Modal, Button } from 'react-bootstrap';

export const DSH_Funcionarios = () => {
    const [showEditModal, setShowEditModal] = useState(false);
    const [showRemoveModal, setShowRemoveModal] = useState(false);
    const [selectedEmployee, setSelectedEmployee] = useState(null);

    const employees = [
        {
            id: 1,
            nome: "Maria Oliveira",
            cargo: "Repositor",
            data_contratacao: "2022-03-10",
            turno: "Manhã"
        },
        {
            id: 2,
            nome: "Carlos Pereira",
            cargo: "Repositor",
            data_contratacao: "2021-08-22",
            turno: "Tarde"
        },
        {
            id: 3,
            nome: "Ana Souza",
            cargo: "Gerente",
            data_contratacao: "2019-11-01",
            turno: "Integral"
        },
        {
            id: 4,
            nome: "Lucas Almeida",
            cargo: "Repositor",
            data_contratacao: "2023-08-22",
            turno: "Tarde"
        },
        {
            id: 5,
            nome: "Nicolas Fonseca",
            cargo: "Repositor",
            data_contratacao: "2020-08-22",
            turno: "Tarde"
        }
    ];
    //MOSTRAR MODAL DE EDIÇÃO
    const handleEdit = (employee) => {
        setSelectedEmployee(employee);
        setShowEditModal(true);
    };
    //MOSTRAR MODAL DE REMOÇÃO
    const handleRemove = (employee) => {
        setSelectedEmployee(employee);
        setShowRemoveModal(true);
    };
    //FECHAR OS MODAIS
    const handleCloseEditModal = () => {
        setShowEditModal(false);
        setSelectedEmployee(null);
    };

    const handleCloseRemoveModal = () => {
        setShowRemoveModal(false);
        setSelectedEmployee(null);
    };
    //-**--**--
    const handleSaveEdit = () => {
        // LOGICA DE EDITAR
        handleCloseEditModal();
    };

    const handleConfirmRemove = () => {
        // Logica para salvar remoção
        handleCloseRemoveModal();
    };

    return (
        <div className="container-fluid">
            <div className="row flex-nowrap">
                <div className="col-md-2">
                    <Sidebar />
                </div>
                <div className="col py-3">
                    <h1>Funcionários</h1>
                    <ul className="list-group">
                        {employees.map((employee) => (
                            <li key={employee.id} className="list-group-item d-flex justify-content-between align-items-center">
                                ID:{employee.id} | {employee.nome} | Cargo: {employee.cargo} | Turno: {employee.turno} | Data de Contratação: {employee.data_contratacao}
                                <div>
                                    <button
                                        className="btn btn-warning btn-sm me-2"
                                        onClick={() => handleEdit(employee)}
                                    >
                                        Editar
                                    </button>
                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => handleRemove(employee)}
                                    >
                                        Remover
                                    </button>
                                </div>
                            </li>
                        ))}
                    </ul>

                    {/*MODAL DE EDIÇÃO */}
                    <Modal show={showEditModal} onHide={handleCloseEditModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Editar Funcionário</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <form>
                                <div className="mb-3">
                                    <label htmlFor="employeeName" className="form-label">Nome</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="employeeName"
                                        defaultValue={selectedEmployee?.nome || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="employeeRole" className="form-label">Cargo</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="employeeRole"
                                        defaultValue={selectedEmployee?.cargo || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="employeeDate" className="form-label">Data de Contratação</label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        id="employeeDate"
                                        defaultValue={selectedEmployee?.data_contratacao || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="employeeShift" className="form-label">Turno</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="employeeShift"
                                        defaultValue={selectedEmployee?.turno || ''}
                                    />
                                </div>
                            </form>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseEditModal}>
                                Fechar
                            </Button>
                            <Button variant="primary" onClick={handleSaveEdit}>
                                Salvar
                            </Button>
                        </Modal.Footer>
                    </Modal>


                    {/* REMOVER */}
                    <Modal show={showRemoveModal} onHide={handleCloseRemoveModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Remover Funcionário</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            Tem certeza de que deseja remover {selectedEmployee?.nome}?
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseRemoveModal}>
                                Cancelar
                            </Button>
                            <Button variant="danger" onClick={handleConfirmRemove}>
                                Remover
                            </Button>
                        </Modal.Footer>
                    </Modal>
                </div>
            </div>
        </div>
    );
};
