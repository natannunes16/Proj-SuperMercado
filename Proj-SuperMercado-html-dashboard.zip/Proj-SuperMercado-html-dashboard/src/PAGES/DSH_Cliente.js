import React, { useState } from 'react';
import Sidebar from './component/Sidebar';
import { Modal, Button } from 'react-bootstrap';

export const DSH_Cliente = () => {
    const [showEditModal, setShowEditModal] = useState(false);
    const [showRemoveModal, setShowRemoveModal] = useState(false);
    const [selectedClient, setSelectedClient] = useState(null);

    const employees = [
        {
            id: 1,
            nome: "João Silva",
            cpf: "123.456.789-00",
            email: "joao.silva@email.com",
            telefone: "(11) 91234-5678",
            endereco: {
                rua: "Rua das Flores",
                numero: 123,
                cidade: "São Paulo",
                estado: "SP",
                cep: "01000-000"
            }
        },
        {
            id: 2,
            nome: "Fernanda Lima",
            cpf: "987.654.321-00",
            email: "fernanda.lima@email.com",
            telefone: "(11) 99876-5432",
            endereco: {
                rua: "Avenida Central",
                numero: 456,
                cidade: "São Paulo",
                estado: "SP",
                cep: "02000-000"
            }
        },
        {
            id: 3,
            nome: "Lucas Oliveira",
            cpf: "456.789.123-00",
            email: "lucas.oliveira@email.com",
            telefone: "(11) 98765-4321",
            endereco: {
                rua: "Rua dos Andradas",
                numero: 789,
                cidade: "São Paulo",
                estado: "SP",
                cep: "03000-000"
            }
        }
    ];
    //MOSTRAR MODAL DE EDIÇÃO
    const handleEdit = (client) => {
        setSelectedClient(client);
        setShowEditModal(true);
    };
    //MOSTRAR MODAL DE REMOÇÃO
    const handleRemove = (client) => {
        setSelectedClient(client);
        setShowRemoveModal(true);
    };
    //FECHAR OS MODAIS
    const handleCloseEditModal = () => {
        setShowEditModal(false);
        setSelectedClient(null);
    };

    const handleCloseRemoveModal = () => {
        setShowRemoveModal(false);
        setSelectedClient(null);
    };
    //-**--**--
    const handleSaveEdit = () => {
        // LOGICA DE EDITAR        
        handleCloseEditModal();
    };

    const handleConfirmRemove = () => {
        // Logica para salvar remoção
        handleCloseRemoveModal();
    };

    return (
        <div className="container-fluid">
            <div className="row flex-nowrap">
                <div className="col-md-2">
                    <Sidebar />
                </div>
                <div className="col py-3">
                    <h1>Clientes</h1>
                    <ul className="list-group">
                        {employees.map((client) => (
                            <li key={client.id} className="list-group-item d-flex justify-content-between align-items-center">
                                ID:{client.id} | {client.nome} | CPF: {client.cpf} |Email: {client.email} | telefone: {client.telefone}
                                <div>
                                    <button
                                        className="btn btn-warning btn-sm me-2"
                                        onClick={() => handleEdit(client)}
                                    >
                                        Editar
                                    </button>
                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => handleRemove(client)}
                                    >
                                        Remover
                                    </button>
                                </div>
                            </li>
                        ))}
                    </ul>

                    {/* EDITAR */}
                    <Modal show={showEditModal} onHide={handleCloseEditModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Editar Cliente</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <form>
                                <div className="mb-3">
                                    <label htmlFor="clientName" className="form-label">Nome</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="clientName"
                                        defaultValue={selectedClient?.nome || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="clientEmail" className="form-label">Email</label>
                                    <input
                                        type="email"
                                        className="form-control"
                                        id="clientEmail"
                                        defaultValue={selectedClient?.email || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="clientTelefone" className="form-label">Telefone</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="clientTelefone"
                                        defaultValue={selectedClient?.telefone || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="clientEndereco" className="form-label">Endereço</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="clientEndereco"
                                        defaultValue={`${selectedClient?.endereco.rua || ''}, ${selectedClient?.endereco.numero || ''}, ${selectedClient?.endereco.cidade || ''} - ${selectedClient?.endereco.estado || ''}, ${selectedClient?.endereco.cep || ''}`}
                                    />
                                </div>
                            </form>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseEditModal}>
                                Fechar
                            </Button>
                            <Button variant="primary" onClick={handleSaveEdit}>
                                Salvar
                            </Button>
                        </Modal.Footer>
                    </Modal>

                    {/* REMOVER */}
                    <Modal show={showRemoveModal} onHide={handleCloseRemoveModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Remover Cliente</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            Tem certeza de que deseja remover {selectedClient?.nome}?
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseRemoveModal}>
                                Cancelar
                            </Button>
                            <Button variant="danger" onClick={handleConfirmRemove}>
                                Remover
                            </Button>
                        </Modal.Footer>
                    </Modal>
                </div>
            </div>
        </div>
    );
};
