import React, { useState } from 'react';
import { Modal, Button } from 'react-bootstrap';
import Sidebar from './component/Sidebar'; // Ajuste o caminho se necessário

export const DSH_Promo = () => {
    const [showEditModal, setShowEditModal] = useState(false);
    const [showRemoveModal, setShowRemoveModal] = useState(false);
    const [selectedPromo, setSelectedPromo] = useState(null);

    const promotions = [
        {
            id: 1,
            produto_id: 1,
            nome_produto: 'Arroz',
            descricao: 'Desconto especial no pacote de 5 kg de arroz branco.',
            desconto_percentual: 10,
            data_inicio: '2024-08-01',
            data_fim: '2024-08-31'
        },
        {
            id: 2,
            produto_id: 2,
            nome_produto: 'Leite',
            descricao: 'Leve 4 e pague 3 no leite integral.',
            desconto_percentual: 25,
            data_inicio: '2024-08-15',
            data_fim: '2024-09-15'
        },
        {
            id: 3,
            produto_id: 3,
            nome_produto: 'Sabão em Pó',
            descricao: 'Sabão em pó com 15% de desconto para compras acima de 3 unidades.',
            desconto_percentual: 15,
            data_inicio: '2024-08-10',
            data_fim: '2024-08-20'
        },
        {
            id: 4,
            produto_id: 4,
            nome_produto: 'Chips',
            descricao: 'Leve 2 e pague 1 na batatinha.',
            desconto_percentual: 10,
            data_inicio: '2024-08-15',
            data_fim: '2024-09-15'
        },
        {
            id: 5,
            produto_id: 5,
            nome_produto: 'Vassoura',
            descricao: 'Leve 3 e pague 2 na vassoura.',
            desconto_percentual: 25,
            data_inicio: '2024-08-15',
            data_fim: '2024-09-15'
        },
        {
            id: 6,
            produto_id: 6,
            nome_produto: 'Cream Cracker',
            descricao: 'Leve 4 e pague 3 na bolacha.',
            desconto_percentual: 15,
            data_inicio: '2024-08-15',
            data_fim: '2024-09-15'
        },
        {
            id: 7,
            produto_id: 7,
            nome_produto: 'Esponja',
            descricao: 'Leve 6 e pague 3 na esponja.',
            desconto_percentual: 25,
            data_inicio: '2024-08-15',
            data_fim: '2024-09-15'
        },
        {
            id: 8,
            produto_id: 8,
            nome_produto: 'Monster',
            descricao: 'Leve 2 e pague 1 no Monster Energy.',
            desconto_percentual: 50,
            data_inicio: '2024-08-15',
            data_fim: '2024-09-15'
        }
    ];
    //MOSTRAR MODAL DE EDIÇÃO
    const handleEdit = (promo) => {
        setSelectedPromo(promo);
        setShowEditModal(true);
    };
    //MOSTRAR MODAL DE REMOÇÃO
    const handleRemove = (promo) => {
        setSelectedPromo(promo);
        setShowRemoveModal(true);
    };
    //FECHAR OS MODAIS
    const handleCloseEditModal = () => {
        setShowEditModal(false);
        setSelectedPromo(null);
    };

    const handleCloseRemoveModal = () => {
        setShowRemoveModal(false);
        setSelectedPromo(null);
    };
    //-**--**--
    const handleSaveEdit = () => {
        // LOGICA DE EDITAR
        handleCloseEditModal();
    };

    const handleConfirmRemove = () => {
        // LOGICA DE REMOVER
        handleCloseRemoveModal();
    };

    return (
        <div className="container-fluid">
            <div className="row flex-nowrap">
                <div className="col-md-2">
                    <Sidebar />
                </div>
                <div className="col py-3">
                    <h1>PROMOÇÃO</h1>
                    <ul className="list-group">
                        {promotions.map((promo) => (
                            <li key={promo.id} className="list-group-item d-flex justify-content-between align-items-center">
                                ID:{promo.id} | ID Do Produto: {promo.produto_id} | Nome da Promoção: {promo.nome_produto} | Desconto Percentual: {promo.desconto_percentual} | Data Inicio: {promo.data_inicio} | Data Fim: {promo.data_fim}
                                <div>
                                    <button
                                        className="btn btn-warning btn-sm me-2"
                                        onClick={() => handleEdit(promo)}
                                    >
                                        Editar
                                    </button>
                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => handleRemove(promo)}
                                    >
                                        Remover
                                    </button>
                                </div>
                            </li>
                        ))}
                    </ul>

                    {/* Edit Modal */}
                    <Modal show={showEditModal} onHide={handleCloseEditModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Editar Promoção</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <form>
                                <div className="mb-3">
                                    <label htmlFor="promoProductName" className="form-label">Nome do Produto</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="promoProductName"
                                        defaultValue={selectedPromo?.nome_produto || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="promoDescription" className="form-label">Descrição</label>
                                    <textarea
                                        className="form-control"
                                        id="promoDescription"
                                        rows="3"
                                        defaultValue={selectedPromo?.descricao || ''}
                                    ></textarea>
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="promoDiscount" className="form-label">Desconto Percentual</label>
                                    <input
                                        type="number"
                                        step="0.01"
                                        className="form-control"
                                        id="promoDiscount"
                                        defaultValue={selectedPromo?.desconto_percentual || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="promoStartDate" className="form-label">Data de Início</label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        id="promoStartDate"
                                        defaultValue={selectedPromo?.data_inicio || ''}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="promoEndDate" className="form-label">Data de Fim</label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        id="promoEndDate"
                                        defaultValue={selectedPromo?.data_fim || ''}
                                    />
                                </div>
                            </form>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseEditModal}>
                                Fechar
                            </Button>
                            <Button variant="primary" onClick={handleSaveEdit}>
                                Salvar
                            </Button>
                        </Modal.Footer>
                    </Modal>

                    {/* Remove Modal */}
                    <Modal show={showRemoveModal} onHide={handleCloseRemoveModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Confirmar Remoção</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            Tem certeza de que deseja remover a promoção para o produto "{selectedPromo?.nome_produto}"?
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseRemoveModal}>
                                Cancelar
                            </Button>
                            <Button variant="danger" onClick={handleConfirmRemove}>
                                Remover
                            </Button>
                        </Modal.Footer>
                    </Modal>
                </div>
            </div>
        </div>
    );
};
