import logo from './logo.svg';
import './App.css';
import {Paginas} from './Paginas';

function App() {
  return (
    <><Paginas /></>
    
  );
}

export default App;
